package com.bussinesdomain.maestros.enums;

public enum CollaboratorState {
    INACTIVE,
    ACTIVE
}
